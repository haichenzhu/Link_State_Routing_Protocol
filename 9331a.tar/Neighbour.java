public class Neighbour {
	
	char id;
	int port;
	double cost;
	
	
	long last_alive_time = 0;
	long last_check_time = 0;
	boolean alive = false;
	
	public Neighbour(char id,int port,double cost) {
		this.id = id;
		this.port = port;
		this.cost = cost;
	}
	
	String getStatus() {
		return alive?"live":"died";
	}
	
	@Override
	public String toString() {
		return String.format("%c is %s,after %d",id,getStatus(),last_check_time);
	}
	
	void setStatus(boolean status,long check_time) {
		if(last_check_time < check_time)
			last_check_time = check_time;
		alive = status;
		if (status && last_alive_time <check_time) {
			last_alive_time = check_time;
		}
	}
	
	boolean exceedTime(long check_time) {
		return (check_time - last_alive_time >= Router.DIE_INTERVAL);
	}
	
	boolean isDied() {
		return !alive;
	}

	
	boolean isLive() {
		return alive;
	}
}
