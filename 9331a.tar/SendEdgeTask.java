import java.util.TimerTask;

public class SendEdgeTask extends TimerTask {
	Router router;
	public SendEdgeTask(Router router) {
		this.router = router;
	}
	
	@Override
	public void run() {
		router.sendEdges();
	}
}
