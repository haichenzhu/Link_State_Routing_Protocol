import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UdpServer implements Runnable{
	Router router;
	public UdpServer(Router r) {
		router = r;
	}
	
	boolean stopped = false;
	synchronized void quit() {
		stopped = true;
	}
	
	synchronized boolean toStop() {
		return stopped;
	}
	
	@Override
	public void run() {
		try {
			DatagramSocket socket = new DatagramSocket(router.port);
			byte[] buffer = new byte[512];
			while(!toStop()) {
				DatagramPacket packet = new DatagramPacket(buffer,buffer.length);
				socket.receive(packet);
				
				String message = new String(packet.getData(), 0, packet.getData().length);
				message = message.trim();  //important !!
				
				router.process(message);
			}
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
