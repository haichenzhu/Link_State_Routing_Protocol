import java.util.TimerTask;

public class SendAliveTask extends TimerTask {
	Router router;
	public SendAliveTask(Router router) {
		this.router = router;
	}
	
	@Override
	public void run() {
		router.sendAlive();
	}
}
