import java.util.TimerTask;

public class CheckNodesTask extends TimerTask {
	Router router;
	public CheckNodesTask(Router router) {
		// TODO Auto-generated constructor stub
		this.router = router;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		router.checkNeighbours();
	}
}
